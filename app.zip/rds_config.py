#config file containing credentials for RDS MySQL instance
db_username = 'admin'
db_password = 'UuiHOi22geiY3sDcCyt4'
db_name = 'nyc_real_estate_dw'